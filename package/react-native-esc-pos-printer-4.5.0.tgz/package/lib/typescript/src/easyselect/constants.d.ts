export declare enum EasySelectDeviceType {
    TCP,
    BLUETOOTH
}
export declare const EasySelectParseTimeout: {
    readonly DEFAULT: number;
};
//# sourceMappingURL=constants.d.ts.map