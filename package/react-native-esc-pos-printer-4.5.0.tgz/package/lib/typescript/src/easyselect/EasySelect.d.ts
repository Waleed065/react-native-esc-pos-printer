import type { EasySelectCreateQROptions, EasySelectInfo, EasySelectParseBeaconOptions, EasySelectParseNFCOptions } from './types';
export declare class EasySelect {
    static createQR({ printerName, deviceType, macAddress, }: EasySelectCreateQROptions): Promise<string>;
    static parseQR(data: string): Promise<EasySelectInfo>;
    static parseNFC(options?: EasySelectParseNFCOptions): Promise<EasySelectInfo[]>;
    static parseBeacon({ uuid, major, minor, timeout, }: EasySelectParseBeaconOptions): Promise<EasySelectInfo>;
}
//# sourceMappingURL=EasySelect.d.ts.map