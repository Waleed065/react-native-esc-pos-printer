export declare function remapConstants<T extends Record<string, string | number>>(constants: T): Record<string, string>;
//# sourceMappingURL=constants.d.ts.map