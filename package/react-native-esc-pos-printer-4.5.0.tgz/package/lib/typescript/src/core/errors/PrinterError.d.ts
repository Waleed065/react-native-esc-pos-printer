export declare class PrinterError extends Error {
    message: string;
    name: string;
    timestamp: number;
    status: string;
    methodName: string;
    constructor(params: {
        status: string;
        message: string;
        methodName: string;
    });
}
//# sourceMappingURL=PrinterError.d.ts.map