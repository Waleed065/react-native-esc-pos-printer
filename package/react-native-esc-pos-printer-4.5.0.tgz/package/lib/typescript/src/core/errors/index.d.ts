export { PrinterDiscoveryError } from './PrinterDiscoveryError';
export { PrinterError } from './PrinterError';
//# sourceMappingURL=index.d.ts.map