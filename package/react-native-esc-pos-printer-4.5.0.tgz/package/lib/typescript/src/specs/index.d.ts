import type { Spec as NativeEscPosPrinterSpec } from './NativeEscPosPrinter';
import type { Spec as NativeEscPosPrinterDiscoverySpec } from './NativeEscPosPrinterDiscovery';
import type { Spec as NativeEscPosPrinterEasySelectSpec } from './NativeEscPosPrinterEasySelect';
declare let EscPosPrinter: NativeEscPosPrinterSpec;
declare let EscPosPrinterDiscovery: NativeEscPosPrinterDiscoverySpec;
declare let EscPosPrinterEasySelect: NativeEscPosPrinterEasySelectSpec;
export { EscPosPrinter, EscPosPrinterDiscovery, EscPosPrinterEasySelect };
//# sourceMappingURL=index.d.ts.map