export declare enum PrinterPaperStatus {
    PAPER_OK,
    PAPER_NEAR_END,
    PAPER_EMPTY
}
export declare enum PrinterPanelSwitchStatus {
    SWITCH_ON,
    SWITCH_OFF
}
export declare enum PrinterDrawerStatus {
    DRAWER_HIGH,
    DRAWER_LOW
}
export declare enum PrinterErrorStatus {
    NO_ERR,
    MECHANICAL_ERR,
    AUTOCUTTER_ERR,
    UNRECOVER_ERR,
    AUTORECOVER_ERR
}
export declare enum PrinterAutoRecoverErrorStatus {
    HEAD_OVERHEAT,
    MOTOR_OVERHEAT,
    BATTERY_OVERHEAT,
    WRONG_PAPER,
    COVER_OPEN
}
export declare enum PrinterBatteryLevelStatus {
    EPOS2_BATTERY_LEVEL_6,
    EPOS2_BATTERY_LEVEL_5,
    EPOS2_BATTERY_LEVEL_4,
    EPOS2_BATTERY_LEVEL_3,
    EPOS2_BATTERY_LEVEL_2,
    EPOS2_BATTERY_LEVEL_1,
    EPOS2_BATTERY_LEVEL_0
}
export declare enum PrinterRemovalWaitingStatus {
    REMOVAL_WAIT_PAPER,
    REMOVAL_WAIT_NONE
}
export declare enum PrinterPaperTakenSensorStatus {
    REMOVAL_DETECT_PAPER,
    REMOVAL_DETECT_PAPER_NONE,
    REMOVAL_DETECT_UNKNOWN
}
export declare enum PrinterUnrecoverErrorStatus {
    HIGH_VOLTAGE_ERR,
    LOW_VOLTAGE_ERR
}
//# sourceMappingURL=status.d.ts.map