export declare enum FontType {
    FONT_A,
    FONT_B,
    FONT_C,
    FONT_D,
    FONT_E
}
export declare enum TextAlignType {
    ALIGN_LEFT,
    ALIGN_CENTER,
    ALIGN_RIGHT
}
//# sourceMappingURL=textStyle.d.ts.map