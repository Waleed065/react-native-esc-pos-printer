export declare enum ImageColorModeType {
    MODE_MONO,
    MODE_GRAY16,
    MODE_MONO_HIGH_DENSITY
}
export declare enum ImageHalftoneType {
    HALFTONE_DITHER,
    HALFTONE_ERROR_DIFFUSION,
    HALFTONE_THRESHOLD
}
export declare enum ImageCompressType {
    COMPRESS_DEFLATE,
    COMPRESS_NONE,
    COMPRESS_AUTO
}
//# sourceMappingURL=image.d.ts.map