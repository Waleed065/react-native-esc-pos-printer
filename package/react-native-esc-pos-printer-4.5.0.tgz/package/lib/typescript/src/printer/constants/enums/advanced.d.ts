export declare enum PrinterLineStyleType {
    LINE_THIN,
    LINE_MEDIUM,
    LINE_THICK,
    LINE_THIN_DOUBLE,
    LINE_MEDIUM_DOUBLE,
    LINE_THICK_DOUBLE
}
export declare enum PrinterDirectionType {
    DIRECTION_LEFT_TO_RIGHT,
    DIRECTION_BOTTOM_TO_TOP,
    DIRECTION_RIGHT_TO_LEFT,
    DIRECTION_TOP_TO_BOTTOM
}
export declare enum PrinterSoundPatternType {
    PATTERN_NONE,
    PATTERN_A,
    PATTERN_B,
    PATTERN_C,
    PATTERN_D,
    PATTERN_E,
    PATTERN_ERROR,
    PATTERN_PAPER_EMPTY,
    PATTERN_1,
    PATTERN_2,
    PATTERN_3,
    PATTERN_4,
    PATTERN_5,
    PATTERN_6,
    PATTERN_7,
    PATTERN_8,
    PATTERN_9,
    PATTERN_10
}
export declare enum PrinterFeedPositionType {
    FEED_PEELING,
    FEED_CUTTING,
    FEED_CURRENT_TOF,
    FEED_NEXT_TOF
}
export declare enum PrinterLayoutType {
    LAYOUT_RECEIPT,
    LAYOUT_RECEIPT_BM,
    LAYOUT_LABEL,
    LAYOUT_LABEL_BM
}
//# sourceMappingURL=advanced.d.ts.map