export declare const DEFAULT_PAPER_WIDTH = 60;
export declare const FULL_IMAGE_WIDTH_RATIO: number;
//# sourceMappingURL=layout.d.ts.map