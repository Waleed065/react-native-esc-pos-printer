import type { PrinterStatusProperties } from '../types';
export declare const PrinterErrorStatusMapping: Record<string, string>;
export declare const PrinterErrorCodeStatusMapping: Record<string, string>;
export declare const PrinterStatusMapping: Record<PrinterStatusProperties, Record<string, string | undefined>>;
export type PrinterErrorCodesMapping = Record<string, string | undefined>;
//# sourceMappingURL=valuesToKeysMappers.d.ts.map