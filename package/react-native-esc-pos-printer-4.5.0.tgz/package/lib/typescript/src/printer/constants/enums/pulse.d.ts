export declare enum PrinterAddPulseDrawerType {
    DRAWER_2PIN,
    DRAWER_5PIN
}
export declare enum PrinterAddPulseTimeType {
    PULSE_100,
    PULSE_200,
    PULSE_300,
    PULSE_400,
    PULSE_500
}
//# sourceMappingURL=pulse.d.ts.map