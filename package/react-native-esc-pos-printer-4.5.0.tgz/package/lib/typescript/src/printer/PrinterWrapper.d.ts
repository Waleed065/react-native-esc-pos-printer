import { PrinterGetSettingsType } from './constants';
import type { AddBarcodeParams, AddCutTypeParam, AddFeedPositionParam, AddFeedUnitParam, AddHLineParams, AddHPositionParam, AddImageParams, AddLayoutParams, AddLogoParams, AddPageAreaParams, AddPageDirectionParam, AddPageLineParams, AddPagePositionParams, AddPageRectangleParams, AddPulseParams, AddSoundParams, AddSymbolParams, AddTextAlignParam, AddTextFontParam, AddTextLangParam, AddTextRotateParam, AddTextSizeParams, AddTextSmoothParam, AddTextStyleParams, AddVLineBeginParams, PrinterInitParams, PrinterSettingsResponse, PrinterStatusResponse } from './types';
export declare class PrinterWrapper {
    private target;
    private printerPaperWidth;
    currentFontWidth: number;
    constructor(target: string);
    init: ({ deviceName, lang }: PrinterInitParams) => Promise<void>;
    connect: (timeout?: number) => Promise<void>;
    disconnect: () => Promise<void>;
    /**
     * Forcefully Clears the command buffer of the printer
     * Caution ☢️: Only use this method if disconnecting the printer is not an option.
     *
     * Disconnecting will automatically clear the command buffer.
     */
    clearCommandBuffer: () => Promise<void>;
    addText: (data: string) => Promise<void>;
    beginTransaction: () => Promise<void>;
    endTransaction: () => Promise<void>;
    addTextLang: (lang: AddTextLangParam) => Promise<void>;
    addFeedLine: (line?: number) => Promise<void>;
    addTextRotate: (rotate?: AddTextRotateParam) => Promise<void>;
    addTextFont: (font?: AddTextFontParam) => Promise<void>;
    addHPosition: (x: AddHPositionParam) => Promise<void>;
    addFeedUnit: (unit: AddFeedUnitParam) => Promise<void>;
    addLineSpace: (linespc: number) => Promise<void>;
    addCut: (type?: AddCutTypeParam) => Promise<void>;
    sendData: (timeout?: number) => Promise<PrinterStatusResponse>;
    getPrinterSetting: (type: PrinterGetSettingsType, timeout?: number) => Promise<PrinterSettingsResponse>;
    getStatus: () => Promise<PrinterStatusResponse>;
    addImage: ({ source, width, color, mode, halftone, brightness, compress, }: AddImageParams) => Promise<void>;
    addLogo: ({ key1, key2 }: AddLogoParams) => Promise<void>;
    addBarcode: ({ data, type, hri, font, width, height, }: AddBarcodeParams) => Promise<void>;
    addSymbol: ({ data, type, level, width, height, size, }: AddSymbolParams) => Promise<void>;
    addPageBegin: () => Promise<void>;
    addPageEnd: () => Promise<void>;
    addPageArea: ({ x, y, width, height, }: AddPageAreaParams) => Promise<void>;
    addPageDirection: (direction: AddPageDirectionParam) => Promise<void>;
    addPagePosition: ({ x, y }: AddPagePositionParams) => Promise<void>;
    addPageLine: ({ x1, y1, x2, y2, style, }: AddPageLineParams) => Promise<void>;
    addPageRectangle: ({ x1, y1, x2, y2, style, }: AddPageRectangleParams) => Promise<void>;
    addCommand: (uint8Array: Uint8Array) => Promise<void>;
    addPulse: ({ drawer, time, }?: AddPulseParams) => Promise<void>;
    addSound: ({ pattern, repeat, cycle, }?: AddSoundParams) => Promise<void>;
    addFeedPosition: (position?: AddFeedPositionParam) => Promise<void>;
    addHLine: ({ x1, x2, style }: AddHLineParams) => Promise<void>;
    addVLineBegin: ({ x, style, }: AddVLineBeginParams) => Promise<number>;
    addVLineEnd: (lineId: number) => Promise<void>;
    addLayout: ({ type, width, height, marginTop, marginBottom, offsetCut, offsetLabel, }: AddLayoutParams) => Promise<void>;
    addRotateBegin: () => Promise<void>;
    addRotateEnd: () => Promise<void>;
    addTextAlign: (align?: AddTextAlignParam) => Promise<void>;
    addTextSize: ({ width, height, }?: AddTextSizeParams) => Promise<void>;
    addTextSmooth: (smooth?: AddTextSmoothParam) => Promise<void>;
    addTextStyle: ({ color, em, reverse, ul, }?: AddTextStyleParams) => Promise<void>;
}
//# sourceMappingURL=PrinterWrapper.d.ts.map