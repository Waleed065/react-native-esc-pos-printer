import type { PrinterSettingsResponse, PrinterSettingsRawResponse } from '../../types';
export declare function parsePrinterSettings(response: PrinterSettingsRawResponse): PrinterSettingsResponse;
//# sourceMappingURL=parsePrinterSettings.d.ts.map