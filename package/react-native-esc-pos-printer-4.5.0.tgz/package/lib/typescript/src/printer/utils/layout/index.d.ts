export { getFontACharsPerLine } from './getFontACharsPerLine';
export { spaceBetween } from './spaceBetween';
//# sourceMappingURL=index.d.ts.map