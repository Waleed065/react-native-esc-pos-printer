import type { SpaceBetweenParams } from '../../types';
export declare const spaceBetween: (length: number, { left, right, textToWrap, textToWrapWidth, gapSymbol, noTrim, }: SpaceBetweenParams) => string;
//# sourceMappingURL=spaceBetween.d.ts.map