export { parsePrinterSettings } from './parsePrinterSettings';
export { parsePrinterStatus } from './parsePrinterStatus';
//# sourceMappingURL=index.d.ts.map