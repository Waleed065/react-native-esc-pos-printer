export declare function getFontACharsPerLine(deviceName: string): Record<number, number>;
//# sourceMappingURL=getFontACharsPerLine.d.ts.map