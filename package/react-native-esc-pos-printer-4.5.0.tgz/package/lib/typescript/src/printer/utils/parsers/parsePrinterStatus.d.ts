import type { PrinterStatusRawResponse, PrinterStatusResponse } from '../../types';
export declare function parsePrinterStatus(response: PrinterStatusRawResponse): PrinterStatusResponse;
//# sourceMappingURL=parsePrinterStatus.d.ts.map