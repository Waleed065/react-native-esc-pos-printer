import type { ComplexErrorData } from '../types';
export declare function throwProcessedError({ methodName, errorCode, messagesMapping, statusMapping, }: {
    methodName: string;
    errorCode: string;
    messagesMapping: Record<string | number, string | undefined>;
    statusMapping?: Record<string | number, string | undefined>;
}): never;
export declare function processComplextError(message: string): ComplexErrorData;
//# sourceMappingURL=errors.d.ts.map