import { Buffer } from 'buffer';
type BufferLoadStream = {
    on(event: 'data', listener: (chunk: Uint8Array) => void): void;
    on(event: 'end', listener: () => void): void;
    once(event: 'error', listener: (error: Error) => void): void;
};
type BufferLoadCallback = (error: Error | null, buffer: Buffer) => void;
export declare class BufferHelper {
    buffers: Buffer[];
    size: number;
    constructor();
    get length(): number;
    concat(buffer: Buffer): BufferHelper;
    empty(): BufferHelper;
    toBuffer(): Buffer;
    toString(encoding: BufferEncoding): string;
    load(stream: BufferLoadStream, callback: BufferLoadCallback): void;
    bytesToString(data: Uint8Array, type: 'base64' | 'hex'): string;
}
export {};
//# sourceMappingURL=BufferHelper.d.ts.map