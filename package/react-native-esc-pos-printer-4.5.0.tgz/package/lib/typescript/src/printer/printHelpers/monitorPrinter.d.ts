import type { Printer } from '../Printer';
import type { PrinterStatusResponse } from '../types';
export declare function monitorPrinter(printer: Printer, listener: (status: PrinterStatusResponse) => void, interval?: number): () => void;
//# sourceMappingURL=monitorPrinter.d.ts.map