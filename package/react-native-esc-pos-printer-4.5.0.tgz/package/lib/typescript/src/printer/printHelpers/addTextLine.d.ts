import type { Printer } from '../Printer';
import type { SpaceBetweenParams } from '../types';
export declare function addTextLine(printer: Printer, params: SpaceBetweenParams, customCharsPerLine?: number): Promise<void>;
//# sourceMappingURL=addTextLine.d.ts.map