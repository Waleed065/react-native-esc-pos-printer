import type { Printer } from '../Printer';
import type { PrinterStatusResponse } from '../types';
type ConnectUntilOptions = {
    maxAttempts?: number;
    connectTimeoutMs?: number;
    initialDelayMs?: number;
    backoffMultiplier?: number;
    maxDelayMs?: number;
};
export declare function tryToConnectUntil(printer: Printer, predicate: (status: PrinterStatusResponse) => boolean, options?: ConnectUntilOptions): Promise<void>;
export {};
//# sourceMappingURL=tryToConnectUntil.d.ts.map