import type { Printer } from '../Printer';
import type { AddViewShotParams } from '../types';
export declare function addViewShot(printer: Printer, { width, viewNode }: AddViewShotParams): Promise<void>;
//# sourceMappingURL=addViewShot.d.ts.map