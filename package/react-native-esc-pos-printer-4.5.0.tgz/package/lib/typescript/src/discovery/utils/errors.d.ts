import { PrinterDiscoveryError } from '../../core';
export declare function getProcessedError({ methodName, errorCode, messagesMapping, statusMapping, }: {
    methodName: string;
    errorCode: string;
    messagesMapping?: Record<string, string | undefined>;
    statusMapping?: Record<string, string | undefined>;
}): PrinterDiscoveryError;
//# sourceMappingURL=errors.d.ts.map