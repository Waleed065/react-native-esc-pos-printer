export { getProcessedError } from './errors';
//# sourceMappingURL=index.d.ts.map