export declare const DEFAULT_DISCOVERY_TIMEOUT: number;
export declare enum DiscoveryDeviceType {
    TYPE_ALL,
    TYPE_PRINTER,
    TYPE_HYBRID_PRINTER,
    TYPE_DISPLAY,
    TYPE_KEYBOARD,
    TYPE_SCANNER,
    TYPE_SERIAL,
    TYPE_CCHANGER,
    TYPE_POS_KEYBOARD,
    TYPE_CAT,
    TYPE_MSR,
    TYPE_GFE,
    TYPE_OTHER_PERIPHERAL
}
export declare enum DiscoveryFilterType {
    FILTER_NAME,
    FILTER_NONE
}
export declare enum DiscoveryPortType {
    PORTTYPE_ALL,
    PORTTYPE_TCP,
    PORTTYPE_BLUETOOTH,
    PORTTYPE_USB,
    PORTTYPE_BLUETOOTH_LE
}
export declare enum DiscoveryDeviceModel {
    MODEL_ALL
}
export declare enum DiscoveryBooleanParams {
    TRUE,
    FALSE
}
export declare enum PrinterPairBluetoothError {
    BT_ERR_PARAM,
    BT_ERR_UNSUPPORTED,
    BT_ERR_CANCEL,
    BT_ERR_ILLEGAL_DEVICE,
    ERR_FAILURE
}
export declare const DiscoveryFilterOption: {
    readonly [x: number]: string;
    readonly TRUE: DiscoveryBooleanParams.TRUE;
    readonly FALSE: DiscoveryBooleanParams.FALSE;
    readonly MODEL_ALL: DiscoveryDeviceModel.MODEL_ALL;
    readonly PORTTYPE_ALL: DiscoveryPortType.PORTTYPE_ALL;
    readonly PORTTYPE_TCP: DiscoveryPortType.PORTTYPE_TCP;
    readonly PORTTYPE_BLUETOOTH: DiscoveryPortType.PORTTYPE_BLUETOOTH;
    readonly PORTTYPE_USB: DiscoveryPortType.PORTTYPE_USB;
    readonly PORTTYPE_BLUETOOTH_LE: DiscoveryPortType.PORTTYPE_BLUETOOTH_LE;
    readonly FILTER_NAME: DiscoveryFilterType.FILTER_NAME;
    readonly FILTER_NONE: DiscoveryFilterType.FILTER_NONE;
    readonly TYPE_ALL: DiscoveryDeviceType.TYPE_ALL;
    readonly TYPE_PRINTER: DiscoveryDeviceType.TYPE_PRINTER;
    readonly TYPE_HYBRID_PRINTER: DiscoveryDeviceType.TYPE_HYBRID_PRINTER;
    readonly TYPE_DISPLAY: DiscoveryDeviceType.TYPE_DISPLAY;
    readonly TYPE_KEYBOARD: DiscoveryDeviceType.TYPE_KEYBOARD;
    readonly TYPE_SCANNER: DiscoveryDeviceType.TYPE_SCANNER;
    readonly TYPE_SERIAL: DiscoveryDeviceType.TYPE_SERIAL;
    readonly TYPE_CCHANGER: DiscoveryDeviceType.TYPE_CCHANGER;
    readonly TYPE_POS_KEYBOARD: DiscoveryDeviceType.TYPE_POS_KEYBOARD;
    readonly TYPE_CAT: DiscoveryDeviceType.TYPE_CAT;
    readonly TYPE_MSR: DiscoveryDeviceType.TYPE_MSR;
    readonly TYPE_GFE: DiscoveryDeviceType.TYPE_GFE;
    readonly TYPE_OTHER_PERIPHERAL: DiscoveryDeviceType.TYPE_OTHER_PERIPHERAL;
};
export declare enum DiscoveryErrorResult {
    ERR_PARAM,
    ERR_ILLEGAL,
    ERR_MEMORY,
    ERR_FAILURE,
    ERR_PROCESSING,
    PERMISSION_ERROR = -2
}
export declare const DiscoveryErrorMessageMapping: {
    [DiscoveryErrorResult.ERR_PARAM]: string;
    [DiscoveryErrorResult.ERR_ILLEGAL]: string;
    [DiscoveryErrorResult.ERR_MEMORY]: string;
    [DiscoveryErrorResult.ERR_FAILURE]: string;
    [DiscoveryErrorResult.ERR_PROCESSING]: string;
    [-2]: string;
};
export declare const PrinterPairBluetoothErrorMessageMapping: {
    [PrinterPairBluetoothError.BT_ERR_CANCEL]: string;
    [PrinterPairBluetoothError.BT_ERR_PARAM]: string;
    [PrinterPairBluetoothError.BT_ERR_UNSUPPORTED]: string;
    [PrinterPairBluetoothError.BT_ERR_ILLEGAL_DEVICE]: string;
    [DiscoveryErrorResult.ERR_FAILURE]: string;
};
export declare const DiscoveryErrorStatusMapping: Record<string, string>;
export declare const PrinterPairBluetoothErrorStatusMapping: Record<string, string>;
export declare const DiscoveryDeviceTypeMapping: Record<string, string>;
//# sourceMappingURL=constants.d.ts.map